__turbopack_load_page_chunks__("/_error", [
  "static/chunks/28d3e_next_dist_compiled_next-devtools_index_d86870fe.js",
  "static/chunks/28d3e_next_dist_compiled_3504f645._.js",
  "static/chunks/28d3e_next_dist_shared_lib_33e51b37._.js",
  "static/chunks/28d3e_next_dist_client_9c0e6217._.js",
  "static/chunks/28d3e_next_dist_bc15d9c8._.js",
  "static/chunks/28d3e_next_error_d2c09a97.js",
  "static/chunks/[next]_entry_page-loader_ts_f75dd1b1._.js",
  "static/chunks/28d3e_react-dom_fd64d8da._.js",
  "static/chunks/28d3e_461eb8b2._.js",
  "static/chunks/[root-of-the-server]__3b984d05._.js",
  "static/chunks/OneDrive_Área de Trabalho_costanza-main_frontend-next_pages__error_2da965e7._.js",
  "static/chunks/9f58e_Área de Trabalho_costanza-main_frontend-next_pages__error_35cdc19d._.js"
])
