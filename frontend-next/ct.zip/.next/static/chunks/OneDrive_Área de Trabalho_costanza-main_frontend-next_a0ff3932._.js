(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f4ea7f23._.js",
  "static/chunks/28d3e_next_dist_compiled_react-dom_18df892f._.js",
  "static/chunks/28d3e_next_dist_compiled_next-devtools_index_c8ba0c91.js",
  "static/chunks/28d3e_next_dist_compiled_95f3eff5._.js",
  "static/chunks/28d3e_next_dist_client_1b902c11._.js",
  "static/chunks/28d3e_next_dist_ca895619._.js",
  "static/chunks/28d3e_@swc_helpers_cjs_4e4d5183._.js"
],
    source: "entry"
});
