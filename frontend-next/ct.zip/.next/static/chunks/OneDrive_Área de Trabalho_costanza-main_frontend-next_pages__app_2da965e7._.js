(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/28d3e_next_dist_compiled_next-devtools_index_d86870fe.js",
  "static/chunks/28d3e_next_dist_compiled_3504f645._.js",
  "static/chunks/28d3e_next_dist_shared_lib_58d59493._.js",
  "static/chunks/28d3e_next_dist_client_9c0e6217._.js",
  "static/chunks/28d3e_next_dist_f62b6492._.js",
  "static/chunks/28d3e_next_app_91b2a6ef.js",
  "static/chunks/[next]_entry_page-loader_ts_e4e5649f._.js",
  "static/chunks/28d3e_react-dom_fd64d8da._.js",
  "static/chunks/28d3e_461eb8b2._.js",
  "static/chunks/[root-of-the-server]__11289724._.js"
],
    source: "entry"
});
