(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__1888e6c5._.css",
  "static/chunks/28d3e_@vercel_analytics_dist_react_index_mjs_96f59363._.js"
],
    source: "dynamic"
});
