(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/28d3e_d76479c8._.js",
  "static/chunks/OneDrive_Área de Trabalho_costanza-main_frontend-next_src_6f06e21e._.js"
],
    source: "dynamic"
});
