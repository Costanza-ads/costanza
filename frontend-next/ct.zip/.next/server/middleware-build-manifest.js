globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/28d3e_next_dist_compiled_next-devtools_index_d86870fe.js",
      "static/chunks/28d3e_next_dist_compiled_3504f645._.js",
      "static/chunks/28d3e_next_dist_shared_lib_58d59493._.js",
      "static/chunks/28d3e_next_dist_client_9c0e6217._.js",
      "static/chunks/28d3e_next_dist_f62b6492._.js",
      "static/chunks/28d3e_next_app_91b2a6ef.js",
      "static/chunks/[next]_entry_page-loader_ts_e4e5649f._.js",
      "static/chunks/28d3e_react-dom_fd64d8da._.js",
      "static/chunks/28d3e_461eb8b2._.js",
      "static/chunks/[root-of-the-server]__11289724._.js",
      "static/chunks/OneDrive_Área de Trabalho_costanza-main_frontend-next_pages__app_2da965e7._.js",
      "static/chunks/9f58e_Área de Trabalho_costanza-main_frontend-next_pages__app_a7acce73._.js"
    ],
    "/_error": [
      "static/chunks/28d3e_next_dist_compiled_next-devtools_index_d86870fe.js",
      "static/chunks/28d3e_next_dist_compiled_3504f645._.js",
      "static/chunks/28d3e_next_dist_shared_lib_33e51b37._.js",
      "static/chunks/28d3e_next_dist_client_9c0e6217._.js",
      "static/chunks/28d3e_next_dist_bc15d9c8._.js",
      "static/chunks/28d3e_next_error_d2c09a97.js",
      "static/chunks/[next]_entry_page-loader_ts_f75dd1b1._.js",
      "static/chunks/28d3e_react-dom_fd64d8da._.js",
      "static/chunks/28d3e_461eb8b2._.js",
      "static/chunks/[root-of-the-server]__3b984d05._.js",
      "static/chunks/OneDrive_Área de Trabalho_costanza-main_frontend-next_pages__error_2da965e7._.js",
      "static/chunks/9f58e_Área de Trabalho_costanza-main_frontend-next_pages__error_35cdc19d._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/28d3e_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f4ea7f23._.js",
    "static/chunks/28d3e_next_dist_compiled_react-dom_18df892f._.js",
    "static/chunks/28d3e_next_dist_compiled_next-devtools_index_c8ba0c91.js",
    "static/chunks/28d3e_next_dist_compiled_95f3eff5._.js",
    "static/chunks/28d3e_next_dist_client_1b902c11._.js",
    "static/chunks/28d3e_next_dist_ca895619._.js",
    "static/chunks/28d3e_@swc_helpers_cjs_4e4d5183._.js",
    "static/chunks/OneDrive_Área de Trabalho_costanza-main_frontend-next_a0ff3932._.js",
    "static/chunks/turbopack-OneDrive_Área de Trabalho_costanza-main_frontend-next_9ec7c691._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];