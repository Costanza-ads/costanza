var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/28d3e_next_ac482dcb._.js")
R.c("server/chunks/[root-of-the-server]__a1fd5b43._.js")
R.m("[project]/OneDrive/Área de Trabalho/costanza-main/frontend-next/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/OneDrive/Área de Trabalho/costanza-main/frontend-next/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/OneDrive/Área de Trabalho/costanza-main/frontend-next/src/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/OneDrive/Área de Trabalho/costanza-main/frontend-next/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/OneDrive/Área de Trabalho/costanza-main/frontend-next/src/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
