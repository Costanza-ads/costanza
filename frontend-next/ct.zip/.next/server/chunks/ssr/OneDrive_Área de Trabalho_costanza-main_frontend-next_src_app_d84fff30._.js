module.exports = [
"[project]/OneDrive/Área de Trabalho/costanza-main/frontend-next/src/app/favicon.ico (static in ecmascript)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.0b3bf435.ico");}),
"[project]/OneDrive/Área de Trabalho/costanza-main/frontend-next/src/app/favicon.ico.mjs { IMAGE => \"[project]/OneDrive/Área de Trabalho/costanza-main/frontend-next/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2fc1$rea__de__Trabalho$2f$costanza$2d$main$2f$frontend$2d$next$2f$src$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Área de Trabalho/costanza-main/frontend-next/src/app/favicon.ico (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2fc1$rea__de__Trabalho$2f$costanza$2d$main$2f$frontend$2d$next$2f$src$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__["default"],
    width: 256,
    height: 256
};
}),
];

//# sourceMappingURL=OneDrive_%C3%81rea%20de%20Trabalho_costanza-main_frontend-next_src_app_d84fff30._.js.map